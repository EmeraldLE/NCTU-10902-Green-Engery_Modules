1.Enter the input file name.
2.You will get a output.txt at your folder.